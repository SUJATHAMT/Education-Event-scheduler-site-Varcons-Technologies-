const express = require("express");
const bodyParser = require("body-parser")
const path = require('path');
const ejs=require('ejs');

const static_path =path.join(__dirname,"../styles");

const auth=require;

let alert = require('alert'); 

app = express().use(express.static(static_path));
app.use(express.json());
app.use(express.urlencoded());

app.set('view engine','ejs');

app.use('/public', express.static('public'));

app.use(bodyParser.urlencoded({
	extended:false
}));

const mongoose = require('mongoose')
mongoose.connect('mongodb+srv://project:events2023@cluster0.6oh0gtt.mongodb.net/Project?retryWrites=true&w=majority',{useNewUrlParser: true,useUnifiedTopology: true}
); 

const db = mongoose.connection;
db.once('open', () => {
    console.log("DB connected successfully")
});

var userSchema = new mongoose.Schema({
    email: String,
    password:String
});

var userModel=mongoose.model('users',userSchema);

var eventSchema = new mongoose.Schema({
    name: String,
    description:String,
    venue:String,
    startDate:String,
    endDate:String,
    startTime:String,
    endTime:String,
    eligible:String,
    contact:String,
});

var edueventsModel=mongoose.model('eduEvents',eventSchema);

var culeventsModel=mongoose.model('culEvents',eventSchema);

var spoeventsModel=mongoose.model('spoEvents',eventSchema);

var userregSchema = new mongoose.Schema({
    eventID:String,
    name: String,
    email:String,
    usn:String,
    branch:String,
    sem:String,

});

var eduregModel=mongoose.model('eduRegister',userregSchema);

var culregModel=mongoose.model('culRegister',userregSchema);

var sporegModel=mongoose.model('spoRegister',userregSchema);

var datetime = new Date();
var reqDate=datetime.toISOString().slice(0,10);

app.get("/", function(req, res) { 
    res.render('index')
 });

 
 
 app.get("/admin_register.ejs", function(req, res) { 
    res.render('admin_register')
 });

 app.post("/admin_register.ejs", function(req, res) {
    
    var userDetails = new userModel({
        email: req.body.email,
        password: req.body.password,
      });
      db.collection('users').count(function(err, count) {
        console.dir(err);
        console.dir(count);
    
        if( count == 0) {
            console.log("No Found Records.");
            userDetails .save().then(()=>{
                alert("Admin created.Login to proceed.")
              }).catch((err)=>{
                console.log('Error during record insertion : ' + err);
        
              })
        }
        else {
            alert("Admin exists")
            console.log("Found Records : " + count);
        }
    });
    } 
          
    );



app.get("/admin_login.ejs", function(req, res) { 
    res.render('admin_login')
    });

app.post("/admin_login.ejs", async(req,res)=> {
        try{const { email, password} = req.body
            
            const useremail=await userModel.findOne({email:email});
            
            if(useremail.password===password){
                res.status(201).render("admin_home");
                
            }
            else{
                alert("Wrong password");
            }
    
        }catch(error){
            alert("Invalid email")
        }
        
    })


app.get("/admin_setpass.ejs", function(req, res) { 
    res.render('admin_setpass')
    });

app.post("/admin_setpass.ejs", async(req,res)=> {
    try{
        const{email,password,cpassword}=req.body
        
        const useremail=await userModel.findOne({email:email});
        
                if(password===cpassword){
            
                    const updateDocument = {
                        $set: {
                           password: cpassword,
                        },
                     };
                     const result = await userModel.updateOne(useremail, updateDocument);
                     
                    res.render("admin_home1")
                }
                else{
                    alert("Password not matching")
                }
        
            }catch(error){
                alert("Invalid email")
            }
            
    });


    
    app.get("/admin.ejs", function(req, res) { 
        res.render('admin')
    });

    
    app.get("/admin_viewreg.ejs", function(req, res) { 
            res.render('admin_viewreg')
    });

    
    app.get("/admin_addevent.ejs", function(req, res) { 
            res.render('admin_addevent')
    });

    
    app.get("/admin_eduevent.ejs", function(req, res) { 
        res.render('admin_eduevent')
    });

    app.post("/admin_eduevent.ejs", function(req, res) {
    
        var edueventDetails = new edueventsModel({
            name: req.body.name,
            description: req.body.description,
            venue: req.body.venue,
            startDate: req.body.startDate,
            endDate: req.body.endDate,
            startTime: req.body.startTime,
            endTime: req.body.endTime,
            eligible: req.body.eligible,
            contact: req.body.contact
          });
          
            edueventDetails .save().then(()=>{
                res.render('admin_addevent')
                alert('Event posted')
                }).catch((err)=>{
                    console.log('Error during record insertion : ' + err);
                    })
            
        });
        
              
        
    
    app.get("/admin_culevent.ejs", function(req, res) { 
    res.render('admin_culevent')
    });

    app.post("/admin_culevent.ejs", function(req, res) {
    
        var culeventDetails = new culeventsModel({
            name: req.body.name,
            description: req.body.description,
            venue: req.body.venue,
            startDate: req.body.startDate,
            endDate: req.body.endDate,
            startTime: req.body.startTime,
            endTime: req.body.endTime,
            eligible: req.body.eligible,
            contact: req.body.contact
          });
          
            culeventDetails .save().then(()=>{
                res.render('admin_addevent')
                alert('Event posted')
                
                }).catch((err)=>{
                    console.log('Error during record insertion : ' + err);
                    })
            
        });
        

    
        app.get("/admin_spoevent.ejs", function(req, res) { 
    res.render('admin_spoevent')
    });

    app.post("/admin_spoevent.ejs", function(req, res) {
    
        var spoeventDetails = new spoeventsModel({
            name: req.body.name,
            description: req.body.description,
            venue: req.body.venue,
            startDate: req.body.startDate,
            endDate: req.body.endDate,
            startTime: req.body.startTime,
            endTime: req.body.endTime,
            eligible: req.body.eligible,
            contact: req.body.contact
          });
          
            spoeventDetails .save().then(()=>{
                console.log('spo event saved')
                res.render('admin_addevent')
                alert('Event posted')
                }).catch((err)=>{
                    console.log('Error during record insertion : ' + err);
                    })
            
        });

    
        app.get("/admin_viewedu.ejs", function(req, res) { 
        edueventsModel.find({endDate:{$gte:reqDate}}).sort({startDate:1}).then((events)=>{
            res.render('admin_viewedu', {
                eventList: events
            })
        })
        });

    app.post("/admin_eduVR.ejs",function(req,res){
        const id=req.body.id;

        eduregModel.find({eventID:id}).sort({usn:1}).then((events)=>{
            
            res.render('admin_eduVR', {
                eventList: events
            })
        })

    })

    app.post("/admin_eduEmail.ejs",function(req,res){
        const id=req.body.id;

        eduregModel.find({eventID:id}).sort({usn:1}).then((events)=>{
            
            res.render('admin_eduEmail', {
                eventList: events
            })
        })

    })


        app.get("/admin_viewcul.ejs", function(req, res) { 
    
            culeventsModel.find({endDate:{$gte:reqDate}}).sort({startDate:1}).then((events)=>{
                
                res.render('admin_viewcul', {
                    eventList: events
                })
            })
            });

            app.post("/admin_culVR.ejs",function(req,res){
                const id=req.body.id;
        
                culregModel.find({eventID:id}).sort({usn:1}).then((events)=>{
                    
                    res.render('admin_culVR', {
                        eventList: events
                    })
                })
        
            })
        
            app.post("/admin_culEmail.ejs",function(req,res){
                const id=req.body.id;
        
                culregModel.find({eventID:id}).sort({usn:1}).then((events)=>{
                    
                    res.render('admin_culEmail', {
                        eventList: events
                    })
                })
        
            })

    

    app.get("/admin_viewspo.ejs", function(req, res) { 
    
           spoeventsModel.find({endDate:{$gte:reqDate}}).sort({startDate:1}).then((events)=>{
            
             res.render('admin_viewspo', {
           eventList: events
            })
                })
                });

                app.post("/admin_spoVR.ejs",function(req,res){
                    const id=req.body.id;
            
                    sporegModel.find({eventID:id}).sort({usn:1}).then((events)=>{
                        
                        res.render('admin_spoVR', {
                            eventList: events
                        })
                    })
            
                })
            
                app.post("/admin_spoEmail.ejs",function(req,res){
                    const id=req.body.id;
            
                    sporegModel.find({eventID:id}).sort({usn:1}).then((events)=>{
                        
                        res.render('admin_spoEmail', {
                            eventList: events
                        })
                    })
            
                })
    

    app.get("/events.ejs", function(req, res) { 
        res.render('events')
        });

    app.get("/events_edu.ejs", function(req, res) { 
        edueventsModel.find({endDate:{$gte:reqDate}}).sort({startDate:1}).then((events)=>{
            console.log(events)
            res.render('events_edu', {
                eventList: events
            })
        })
        
        });

    app.post("/events_edu.ejs", function(req, res) {
        const id=req.body.id;
        console.log(id)
        res.render('events_edureg',{id})
                
            });

    app.get("/events_cul.ejs", function(req, res) { 
        culeventsModel.find({endDate:{$gte:reqDate}}).sort({startDate:1}).then((events)=>{
            console.log(events)
            res.render('events_cul', {
                eventList: events
            })
        })
       
        });

    app.post("/events_cul.ejs", function(req, res) {
            const id=req.body.id;
            console.log(id)
            res.render('events_culreg',{id})
                    
            });

    app.get("/events_spo.ejs", function(req, res) { 
        spoeventsModel.find({endDate:{$gte:reqDate}}).sort({startDate:1}).then((events)=>{
            console.log(events)
            res.render('events_spo', {
                eventList: events
            })
        })
       
        });

    app.post("/events_spo.ejs", function(req, res) {
        const id=req.body.id;
        console.log(id)
        res.render('events_sporeg',{id})
                    
            });

     app.get("/events_edureg.ejs", function(req, res) { 
        res.render('events_edureg')
        });

    app.post("/events_edureg.ejs", function(req, res) {
        var userDetails = new eduregModel({
            eventID: req.body.id,
            name: req.body.name,
            email: req.body.email,
            usn: req.body.usn,
            branch: req.body.branch,
            sem: req.body.sem
          });
          
            userDetails .save().then(()=>{
                alert("Successfully registered")
                res.render('events')
                  }).catch((err)=>{
                    console.log('Error during record insertion : ' + err);
            
                  })
                        
                });

    app.get("/events_culreg.ejs", function(req, res) { 
        res.render('events_culreg')
        });

        app.post("/events_culreg.ejs", function(req, res) {
            var userDetails = new culregModel({
                eventID: req.body.id,
                name: req.body.name,
                email: req.body.email,
                usn: req.body.usn,
                branch: req.body.branch,
                sem: req.body.sem
              });
              
                userDetails .save().then(()=>{
                    alert("Successfully registered")
                    res.render('events')
                      }).catch((err)=>{
                        console.log('Error during record insertion : ' + err);
                
                      })
                            
                    });

    app.get("/events_sporeg.ejs", function(req, res) { 
        res.render('events_sporeg')
        });

        app.post("/events_sporeg.ejs", function(req, res) {
            var userDetails = new sporegModel({
                eventID: req.body.id,
                name: req.body.name,
                email: req.body.email,
                usn: req.body.usn,
                branch: req.body.branch,
                sem: req.body.sem
              });
              
                userDetails .save().then(()=>{
                    alert("Successfully registered")
                    res.render('events')
                      }).catch((err)=>{
                        console.log('Error during record insertion : ' + err);
                
                      })
                            
                    });
    




    app.listen(8000, function(){
    console.log("server is running on port 8000");
});